��﻿param([string] $kustoquery, [string] $wmiquery, [string] $select)

# Read the queries and selects
$kustoquery  = [System.Text.Encoding]::UTF8.GetString([System.Convert]::FromBase64String($kustoquery.Substring(2))).Split([Environment]::NewLine, [StringSplitOptions]::RemoveEmptyEntries)
$wmiqueries  = [System.Text.Encoding]::UTF8.GetString([System.Convert]::FromBase64String($wmiquery.Substring(2))).Split([Environment]::NewLine, [StringSplitOptions]::RemoveEmptyEntries)
$selects = [System.Text.Encoding]::UTF8.GetString([System.Convert]::FromBase64String($select.Substring(2))).Split([Environment]::NewLine, [StringSplitOptions]::RemoveEmptyEntries)


#create the result xml writer
$sb = New-Object System.Text.StringBuilder
$sw = New-Object System.IO.StringWriter($sb)
$writer = New-Object System.Xml.XmlTextWriter($sw)
$writer.WriteStartDocument()
$writer.WriteStartElement("result")
$writer.WriteAttributeString("ResultCode", 0x00000000 )

# A helper function to create a datatable of properties
function CreateTableFromPropertyList
{
    param ([string[]]$properties, [String[]]$propertyTypes)

    $dt = New-Object system.Data.DataTable

    # Add Device column first
    $col_device = New-Object system.Data.DataColumn 'Device',([Microsoft.ConfigurationManagement.AdminConsole.CMPivotParser.Device])
    $dt.Columns.Add($col_device)

    # Add the rest properties to columns
    for( $index = 0; $index -lt $properties.Length; $index++ )
    {
        # Get the column datatype
        switch($propertyTypes[$index])
        {
            "Boolean"
            {
                $colType = [System.Boolean]
                break
            }
            "Number"
            {
                $colType = [System.Int64]
                break
            }
            "String"
            {
                $colType = [System.String]
                break
            }
            "TimeSpan"
            {
                $colType = [System.TimeSpan]
                break
            }
            "DateTime"
            {
                $colType = [System.DateTime]
                break                
            }
            default
            {
                throw
            }
        }
        $column = New-Object system.Data.DataColumn $properties[$index], ($colType)
        $dt.Columns.Add($column)
    }

    return ,$dt
}

Try
{
    # arm64 client - ccmexec runs as 32 bit process in arm64 clients
    $isArm64Client = if (([System.Environment]::Is64BitOperatingSystem -eq $true) -and ([System.Environment]::Is64BitProcess -eq $false))
    {
        "true"
    }
    else 
    {
        "false"
    }
    # Registry view to be used for clients 
    $cmRegistryView = if ($isArm64Client -eq $true) 
    {
        [Microsoft.Win32.RegistryView]::Registry32
    }
    else 
    {
        [Microsoft.Win32.RegistryView]::Registry64 
    }

    # Lookup the CCM directory
    $key = [Microsoft.Win32.RegistryKey]::OpenBaseKey([Microsoft.Win32.RegistryHive]::LocalMachine, $cmRegistryView)
    $subKey =  $key.OpenSubKey("SOFTWARE\Microsoft\SMS\Client\Configuration\Client Properties")
    $ccmdir = $subKey.GetValue("Local SMS Path")
    $key.Close()
    $binName = 'AdminUI.CMPivotParser.dll'
    $binPath = (join-path $ccmdir $binName)
        
    # Try to load AdminUI.CMPivotParser.dll from ccm binary folder
    try
    {
        [System.Reflection.Assembly]::LoadFile($binPath) | Out-Null
    }
    catch
    {   
        throw 'Failed to load CMPivotParser'
    }

    # Create the resultant data table list
    $datatables = New-Object System.Collections.Generic.List[Data.DataTable]

    # For each query
    for( $queryIndex = 0; $queryIndex -lt $wmiqueries.Length; $queryIndex++ )
    {
        # For this index
        $wmiquery = $wmiqueries[$queryIndex]
        $select = $selects[$queryIndex]

        # Parse the select parameter
        $propertyFilter = @()
        $propertyTypes = @()
        $propertySerializer = @()

        foreach($p in $select.Split(','))
        {
            # Parse property definition
            $p = $p.Split(':')

            # Generate a property serializer
            if( $p[2] -eq "KiloBytes" )
            {   
                $propertyFilter+= $p[0]                
                $propertyTypes+= $p[1]
                $propertySerializer += { Param( [Object] $val ) return [Int64]::Parse($val.ToString()) -shr 10 }
            }
            elseif( $p[2] -eq "MegaBytes" )
            {   
                $propertyFilter+= $p[0]                
                $propertyTypes+= $p[1]
                $propertySerializer += { Param( [Object] $val ) return [Int64]::Parse($val.ToString()) -shr 20 }
            }
            elseif( $p[2] -eq "GigaBytes" )
            {   
                $propertyFilter+= $p[0]                
                $propertyTypes+= $p[1]
                $propertySerializer += { Param( [Object] $val ) return [Int64]::Parse($val.ToString()) -shr 30 }
            }
            elseif( $p[2] -eq "Seconds" )
            {   
                $propertyFilter+= $p[0]                
                $propertyTypes+= $p[1]
                $propertySerializer += { Param( [Object] $val ) return [Int64]::Parse($val.ToString())/1000 }
            }
            elseif( $p[2] -eq "HexSring" )
            {   
                $propertyFilter+= $p[0]                
                $propertyTypes+= $p[1]
                $propertySerializer += { Param( [Object] $val ) return "0x"+[Int64]::Parse($val.ToString()).ToString("X") }
            }
            elseif( $p[2] -eq "DateString" )
            {   
                # The DateString field format is "ddddddddHHMMSS.mmmmmm:000" --> %d Days 02:01:01 Hours
                $propertyFilter+= $p[0]                
                $propertyTypes+= $p[1]
                $propertySerializer += { 
                    Param( [Object] $val ) 
                    $days = [Int64]::Parse( $val.SubString(0, 8))
                    $hours = $val.SubString(8, 2)
                    $min = $val.SubString(10, 2)
                    $seconds = $val.SubString(12, 2)
                    return "${days} Days ${hours}:${min}:${seconds} Hours"
                }
            }
            elseif ( $p[1] -eq 'Number' )
            {
                $propertyFilter+= $p[0]                
                $propertyTypes+= $p[1]
                $propertySerializer += { Param( [Object] $val ) return [Int64]::Parse($val.ToString()) }
            }
            elseif ( $p[1] -eq 'Boolean' )
            {
                $propertyFilter+= $p[0]                
                $propertyTypes+= $p[1]
                $propertySerializer += { Param( [Object] $val ) return [Boolean]::Parse($val.ToString()) }
            }
            elseif( $p[1] -eq 'DateTime' )
            {
                $propertyFilter+= $p[0]                
                $propertyTypes+= $p[1]  
                $propertySerializer += { 
                    Param( [Object] $val )           
            
                    try
                    {
                       $val = [System.Management.ManagementDateTimeconverter]::ToDateTime($val)
                         
                       #Sql.MinDateTime -> Null
                       if( $val -lt (get-date -Year 1753 -Month 1 -Day 1 -Hour 0 -Minute 0 -Second 0 -Millisecond 0))
                       {     
                          return $null
                       }
                       else
                       {
                          return $val
                       }
                     
                    }
                    catch
                    {
                        return $null
                    }
                }
            }
            elseif( $p[1] -ne 'Device' )
            {
                $propertyFilter+= $p[0]                
                $propertyTypes+= $p[1]
                $propertySerializer += { Param( [Object] $val ) return $val.ToString() }                
            }
        }

        # Create a data table to store the results of this query
        $dt = CreateTableFromPropertyList -properties $propertyFilter -propertyTypes $propertyTypes

        #Create the result set
        $results = New-Object System.Collections.Generic.List[Object]

        #deal with one-offs that don't work well over WMI
        if( $wmiquery -eq 'SMBConfig' )
        {
            # Get Smb Config
            $smbConfig = Get-SmbServerConfiguration -ErrorAction Stop| Select-object -Property $propertyFilter

            #Add to results list
            $results.Add($smbConfig)
        }
        elseif( $wmiquery -eq 'Users' )
        {
            $users = New-Object System.Collections.Generic.List[String]

            foreach( $user in (get-WmiObject -class Win32_LoggedOnuser -ErrorAction Stop | Select Antecedent))
            {
                $parts = $user.Antecedent.Split("""")
        
                # If this is not a built-in account
                if(( $parts[1] -ne "Window Manager" ) -and (($parts[1] -ne $env:COMPUTERNAME) -or (($parts[3] -notlike "UMFD-*")) -and ($parts[3] -notlike "DWM-*")))
                {
                    # add to list
                    $users.Add($parts[1] + "\" + $parts[3])            
                }
            }
   
            # Create unique set of users
            $users | sort-object -Unique | foreach-object { $results.Add(@{ UserName = $_ }) }         
        }
        elseif( $wmiquery -eq 'IPConfig' )
        {
            $ipconfigs = (Get-NetIPConfiguration -ErrorAction Stop)

            foreach( $ipconfig in $ipconfigs )
            {
                $hash = @{
                    InterfaceAlias = $ipconfig.InterfaceAlias
                    Name = $ipconfig.NetProfile.Name
                    InterfaceDescription = $ipconfig.InterfaceDescription
                    Status = $ipconfig.NetAdapter.Status
                    IPV4Address = $ipconfig.IPv4Address.IPAddress
                    IPV6Address = $ipconfig.IPv6Address.IPAddress
                    IPV4DefaultGateway = $ipconfig.IPv4DefaultGateway.NextHop
                    IPV6DefaultGateway = $ipconfig.IPv6DefaultGateway.NextHop
                    DNSServerList = ($ipconfig.DNSServer.ServerAddresses -join "; ")
                }
    
                $results.add($hash)
            }
        }
        elseif( $wmiquery -eq 'Connections' )
        {
            $netstat = "$Env:Windir\system32\netstat.exe"
            $rawoutput = & $netstat -f
            $netstatdata = $rawoutput[3..$rawoutput.count] | ConvertFrom-String | select p2,p3,p4,p5 | where p5 -eq 'established' | select P4  

            foreach( $data in $netstatdata)
            {        
                #Add to results list
                $hash = @{ Server = $data.P4.Substring(0,$data.P4.LastIndexOf(":")) }
                $results.Add($hash )
            }        
        }
        elseif( $wmiquery -eq 'EPStatus' )
        {
            $epStatus = (Get-MpComputerStatus -ErrorAction Stop)

            $hash = @{                 
                AMServiceEnabled = $epStatus.AMServiceEnabled
                AntispywareEnabled = $epStatus.AntispywareEnabled
                AntispywareSignatureLastUpdated = $epStatus.AntispywareSignatureLastUpdated
                AntispywareSignatureVersion = $epStatus.AntispywareSignatureVersion
                AntivirusEnabled = $epStatus.AntivirusEnabled
                AntivirusSignatureLastUpdated = $epStatus.AntivirusSignatureLastUpdated
                AntivirusSignatureVersion = $epStatus.AntivirusSignatureVersion
                BehaviorMonitorEnabled = $epStatus.BehaviorMonitorEnabled
                IoavProtectionEnabled = $epStatus.IoavProtectionEnabled
                IsTamperProtected = $epStatus.IsTamperProtected
                NISEnabled = $epStatus.NISEnabled
                NISSignatureLastUpdated = $epStatus.NISSignatureLastUpdated
                NISSignatureVersion = $epStatus.NISSignatureVersion
                OnAccessProtectionEnabled = $epStatus.OnAccessProtectionEnabled
                QuickScanEndTime = $epStatus.QuickScanEndTime
                RealTimeProtectionEnabled = $epStatus.RealTimeProtectionEnabled            
            }
                
            $results.Add($hash)
        }
        elseif( $wmiquery.StartsWith('Updates') )
        {
            # Default server selection
            $serverSelection = 0 

            # if server selection has been specified then use it
            $first = $wmiquery.IndexOf("(")

            if( $first -ne -1 ) 
            {
                $last = $wmiquery.LastIndexOf(")")            
                $serverSelection = [Int32]::Parse( $wmiquery.Substring($first+1, $last-$first-1))
            }

            # Create an update session object
            $Session =  [activator]::CreateInstance([type]::GetTypeFromProgID("Microsoft.Update.Session",$null))
            $Searcher = $Session.CreateUpdateSearcher()
            $Searcher.ServerSelection = $serverSelection

            # Search for any uninstalled updates
            $MissingUpdates = $Searcher.Search("DeploymentAction=* and IsInstalled=0 and Type='Software'")  
    
            if ($MissingUpdates.Updates.Count -gt 0) 
            {
                foreach( $Update in $MissingUpdates.Updates )
                {   
                    $KBArticleIDs = ""
                    foreach( $KB in $Update.KBArticleIDs)
                    {
                        if( $KBAticleIDs.Length -gt 0 )
                        {
                            $KBArticleIDs = $KBArticleIDs + ","
                        }

                        $KBArticleIDs = $KBArticleIDs + "KB$KB"
                    }
            
                    $SecurityBulletinIDs = ""
                    foreach( $BulletinID in $Update.SecurityBulletinIDs)
                    {
                        if( $SecurityBulletinIDs.Length -gt 0 )
                        {
                            $SecurityBulletinIDs = $SecurityBulletinIDs + ","
                        }

                        $SecurityBulletinIDs = $SecurityBulletinIDs + $BulletinID
                    }

                    $Categories = ""
                    foreach( $Category in $Update.Categories)
                    {
                        if( $Categories.Length -gt 0 )
                        {
                            $Categories = $Categories + ","
                        }

                        $Categories = $Categories + $Category.Name
                    }

                    #Add to results list
                    $hash = @{                 
                        Title = $Update.Title
                        RebootRequired = $Update.RebootRequired
                        LastDeploymentChangeTime = $Update.LastDeploymentChangeTime
                        UpdateID = $Update.Identity.UpdateID
                        KBArticleIDs = $KBArticleIDs
                        SecurityBulletinIDs = $SecurityBulletinIDs                                
                        Categories = $Categories                
                    }
                
                    $results.Add($hash)            
                }
            } 
        }
        elseif( $wmiquery -eq 'AppCrash' )
        {
            Try
            {
                $crashes = get-eventlog -ErrorAction Stop -LogName Application  -After (Get-Date).AddDays(-7) -InstanceId 1000 -Source 'Application Error'

                foreach ($crash in $crashes)  
                {
                    $hash = @{
                            FileName = $crash.ReplacementStrings[0]
                            Version = $crash.ReplacementStrings[1]
                            ReportId = $crash.ReplacementStrings[12]
                            DateTime = $crash.TimeGenerated
                    } 
    
                    $results.Add($hash)        
                }
            }
            Catch
            {
            }
        }
        elseif( $wmiquery -eq 'AadStatus' )
        {
            $dsregcmd = "$Env:Windir\system32\dsregcmd.exe"
            $hash = @{}

            if( Test-Path -Path $dsregcmd -PathType Leaf )            
            {
                $rawoutput = & $dsregcmd /status

                foreach( $line in $rawoutput )
                {
                    $sep = $line.IndexOf(":")

                    if( $sep -ne -1 )
                    {
                        $propName = $line.SubString(0, $sep).Trim()
                        $propValue = $line.SubString($sep+1).Trim()

                        if( $propValue -eq 'YES' )
                        {
                            $propValue = $true
                        }
                        elseif( $propValue -eq 'NO' )
                        {
                            $propValue = $false
                        }

                        $hash.Add($propName,$propValue)

                    }
                }
            }
            else
            {   
                # On an OS that does not support AAD Join         
                $hash.Add("EnterpriseJoined",$false)
                $hash.Add("AzureAdJoined",$false)
                $hash.Add("WorkplaceJoined",$false)

                $OSInfo=(Get-CIMInstance Win32_ComputerSystem)

                if( $OSInfo.PartOfDomain )
                {
                    $hash.Add("DomainJoined",$true)
                    $hash.Add("DomainName",$OSInfo.Domain)
                }
                else
                {
                    $hash.Add("DomainJoined",$false)
                }
            }

            $results.Add($hash)
        }
        elseif( $wmiquery -eq 'Administrators' )
        {
            $adminsCmd = {get-localgroupmember -SID S-1-5-32-544 -ErrorAction Stop}
            $admins = if ($isArm64Client -eq $true) 
            {
                # run this cmd using 64-bit PS for arm64 clients since LocalAccounts module is not available on 32-bit PS (ccmexec is 32-bit on arm64 clients) running on 64-bit system
                & “$env:SystemRoot\sysnative\WindowsPowerShell\v1.0\powershell.exe” -ExecutionPolicy Restricted -WindowStyle Hidden -NoProfile -NonInteractive -Command $adminsCmd
            }
            else 
            {
                & $adminsCmd
            }
            
            foreach( $admin in $admins )
            {
                $hash = @{
                    ObjectClass = $admin.ObjectClass
                    Name = $admin.Name
                    PrincipalSource = $admin.PrincipalSource
                }

                $results.Add($hash)        
            }
        }
        elseif ($wmiquery.StartsWith("File(") )
        {
            $first = $wmiquery.IndexOf("'")+1
            $last = $wmiquery.LastIndexOf("'")
    
            $fileSpec = [System.Environment]::ExpandEnvironmentVariables( $wmiquery.Substring($first, $last-$first))
   
            foreach( $file in (Get-Item -Force -ErrorAction SilentlyContinue -Path $filespec))
            {
                $fileSHA256 = ""
                $fileMD5 = ""

                Try
                {
                    $fileSHA256 = (get-filehash -ErrorAction SilentlyContinue -Path $file).Hash 
                    $fileMD5 = (get-filehash -ErrorAction SilentlyContinue -Path $file -Algorithm MD5).Hash
                }
                Catch
                {
                }

                 $hash = @{
                    FileName = $file.FullName
                    Mode = $file.Mode
                    LastWriteTime = $file.LastWriteTime
                    Size = $file.Length
                    Version = $file.VersionInfo.ProductVersion
                    SHA256Hash = $fileSHA256
                    MD5Hash = $fileMD5
                 }

                 $results.Add($hash)

            }
        }
        elseif ($wmiquery.StartsWith("FileContent(") )
        {
            $first = $wmiquery.IndexOf("'")+1
            $last = $wmiquery.LastIndexOf("'") 

            $filepath = [System.Environment]::ExpandEnvironmentVariables( $wmiquery.Substring($first, $last-$first) )   

            #verify if the file exists
            if( [System.IO.File]::Exists($filepath) )
            {        
                $lines = (get-content -path $filepath -ErrorAction Stop)
                
                # our code handles lines as list of object
                # get-content return list of lines if multiple lines are present
                # in case of single line a string is returned which is casted to list
                if ($lines -is [string]) {
                    $lines = @($lines)
                }
                for ($index = 0; $index -lt $lines.Length; $index++)
                {
                    $line = $lines[$index]

                    $hash = @{
                            Line = $index+1
                            Content = $line
                    }
                    $results.Add($hash)
                }
            }
        }
        elseif ($wmiquery.StartsWith("EventLog(") )
        {
            $first = $wmiquery.IndexOf("'")+1
            $last = $wmiquery.LastIndexOf("'")    
            $logName = $wmiquery.Substring($first, $last-$first)

            $first_time = $wmiquery.LastIndexOf(",")+1
            $last_time = $wmiquery.LastIndexOf(")")
            $secondsAgo = [System.Int64]::Parse($wmiquery.Substring($first_time, $last_time-$first_time))
    
            $events = get-eventlog -LogName $logName -ErrorAction Stop -After (Get-Date).AddSeconds(-1*$secondsAgo)
    
            foreach ($event in $events)  
            {
                $hash = @{
                        DateTime = $event.TimeGenerated
                        EntryType = $event.EntryType
                        Source = $event.Source
                        EventID = $Event.EventID
                        Message = $Event.Message
                } 
    
                $results.Add($hash)        
            }
        }
        elseif ($wmiquery.StartsWith("CcmLog(") )
        {
            $first = $wmiquery.IndexOf("'")+1
            $last = $wmiquery.LastIndexOf("'")    
            $logFileName = $wmiquery.Substring($first, $last-$first)

            $first_time = $wmiquery.LastIndexOf(",")+1
            $last_time = $wmiquery.LastIndexOf(")")
            $secondsAgo = [System.Int64]::Parse($wmiquery.Substring($first_time, $last_time-$first_time))

            $key = [Microsoft.Win32.RegistryKey]::OpenBaseKey([Microsoft.Win32.RegistryHive]::LocalMachine, $cmRegistryView)
            $subKey =  $key.OpenSubKey("SOFTWARE\Microsoft\CCM\Logging\@Global")
            $ccmlogdir = $subKey.GetValue("LogDirectory")
            $key.Close()
            $logPath = (join-path $ccmlogdir ($logFileName+".log"))

            #verify format of file name
            if(( $logFileName -match '[\w\d-_@]+' ) -and ([System.IO.File]::Exists($logPath)))
            {        
                $lines = (get-content -path $logpath -ErrorAction Stop)

                [regex]$ccmLog = '<!\[LOG\[(?<logtext>.*)\]LOG\]!><\s*time\s*\=\s*"(?<time>\d\d:\d\d:\d\d)[^"]+"\s+date\s*\=\s*"(?<date>[^"]+)"\s+component\s*\=\s*"(?<component>[^"]*)"\s+context\s*\=\s*"(?<context>[^"]*)"\s+type\s*\=\s*"(?<type>[^"]+)"\s+thread\s*\=\s*"(?<thread>[^"]+)"\s+file\s*\=\s*"(?<file>[^"]+)"\s*>'

                for( $index = $lines.Length-1; $index -ge 0; $index-- )
                {
                    $line = $lines[$index]

                    $m = $ccmLog.Match($line)

                    if( $m.Success -eq $true )
                    {
                        $hash = @{
                            LogText = $m.Groups["logtext"].Value
                            DateTime = ([DateTime]($m.Groups["date"].Value +' '+ $m.Groups["time"].Value)).ToUniversalTime()
                            Component = $m.Groups["component"].Value
                            Context = $m.Groups["context"].Value
                            Type = $m.Groups["type"].Value
                            Thread = $m.Groups["thread"].Value
                            File = $m.Groups["file"].Value
                        }
                        
                        # Filter out logs based on timespan
                        if ( [System.DateTime]::Compare($hash.DateTime, (Get-Date).AddSeconds(-1*$secondsAgo).ToUniversalTime()) -lt 0 )
                        {
                            break
                        }
                        else
                        {
                            $results.Add($hash)
                        }
                    }   
                }

                # Reverse the results list to ascending datetime
                $results.Reverse()
            }
        }
        elseif ($wmiquery.StartsWith("WinEvent("))
        {
            $first = $wmiquery.IndexOf("'")+1
            $last = $wmiquery.LastIndexOf("'")
            $logFileName =  $wmiquery.Substring($first, $last-$first)

            $first_time = $wmiquery.LastIndexOf(",")+1
            $last_time = $wmiquery.LastIndexOf(")")
            $secondsAgo = [System.Int64]::Parse($wmiquery.Substring($first_time, $last_time-$first_time))

            $ComputerName = [System.Environment]::MachineName 
            $EventStartDate = (Get-Date).AddSeconds(-1*$secondsAgo)
            $EventEndTime = (Get-Date)
            $filterTable = @{logname = $logFileName; StartTime=$EventStartDate; EndTime=$EventEndTime}

            # Filter out the winEvent logs that we need
            try
            {
                $winEvents = Get-WinEvent -ComputerName $ComputerName -FilterHashTable $filterTable  -ErrorAction Stop
            }
            catch
            {
            }

            foreach ($winEvent in $winEvents)  
            {
                $hash = @{
                        DateTime = $winEvent.TimeCreated
                        LevelDisplayName = $winEvent.LevelDisplayName
                        ProviderName = $winEvent.ProviderName
                        ID = $winEvent.ID
                        Message = $winEvent.Message
                } 
    
                $results.Add($hash)        
            }
        }
        elseif ($wmiquery.StartsWith("Registry(") )
        {
            $first = $wmiquery.IndexOf("'")+1
            $last = $wmiquery.LastIndexOf("'")
            $regSpec =  $wmiquery.Substring($first, $last-$first)
   
            $result = New-Object System.Collections.Generic.List[Object]

            foreach( $regKey in (Get-Item -ErrorAction SilentlyContinue -Path $regSpec) )
            {
                foreach( $regValue in $regKey.Property )
                {
                    $val = $regKey.GetValue($regValue)

                    if ( $val -eq $null)
                    { 
                        $valDefaultProp = Get-ItemProperty -Path $regSpec
                        $valDefault = $valDefaultProp."(Default)"

                        $hashDefault = @{
                            Key = $regKey.Name
                            Property = '(Default)' 
                            Value = $valDefault.ToString()
                        }

                        $results.Add($hashDefault)
                    }
                    else
                    {
                        if( $val.GetType() -eq [Byte[]] )
                        {
                            $val = [System.BitConverter]::ToString($val)
                        }
                        elseif( $val.GetType() -eq [String[]] )
                        {
                            $val = [System.String]::Join(", ", $val)
                        }

                        $hash = @{
                            Key = $regKey.Name
                            Property = $regValue
                            Value = $val.ToString()
                        }

                        $results.Add($hash)
                    }
                }
            }
        }
        elseif ($wmiquery.StartsWith("RegistryKey(") )
        {
            $first = $wmiquery.IndexOf("'")+1
            $last = $wmiquery.LastIndexOf("'")
            $regSpec =  $wmiquery.Substring($first, $last-$first)
   
            $result = New-Object System.Collections.Generic.List[Object]

            foreach( $regKey in (Get-Item -ErrorAction SilentlyContinue -Path $regSpec) )
            {
                $hash = @{
                    Key = $regKey.Name
                }

                $results.Add($hash)
            }

        }
        elseif ($wmiquery.StartsWith("ProcessModule(") )
        {
            $first = $wmiquery.IndexOf("'")+1
            $last = $wmiquery.LastIndexOf("'")
            $processName =  $wmiquery.Substring($first, $last-$first)

            $modules = get-process -name $processName -module -ErrorAction SilentlyContinue

            foreach ($module in $modules)  
            {
                $hash = @{
                        ModuleName = $module.ModuleName
                        FileName = $module.FileName
                        FileVersion = $module.FileVersion
                        Size = $module.Size
                        MD5Hash = (get-filehash -ErrorAction SilentlyContinue -Path $module.FileName -Algorithm MD5).Hash
                } 
    
                $results.Add($hash)     
            }

        }
        else
        {
            $namespace = "root/cimv2"

            # if there is a namespace
            if( ($wmiquery.StartsWith("root/")) -and ($wmiquery.Contains(":")))
            {
                $seperator = $wmiquery.IndexOf(":")
                $namespace =  $wmiquery.Substring(0, $seperator)
                $wmiquery = $wmiquery.Substring($seperator+1)
            }

            # Execute the query
            $wmiresult = (get-wmiobject -query $wmiquery -Namespace $namespace -ErrorAction Stop) 

            # create result set
            $result = New-Object System.Collections.Generic.List[Object]

            foreach( $obj in $wmiresult )
            {
                $hash = @{}

                for( $i=0; $i -lt $propertyFilter.Length; $i++ )
                {            
                   $propName = $propertyFilter[$i]
                   $propValue = $obj[$propName]
 
                   if( $propValue -ne $null)
                   {
                       $hash[$propName] = $($propertySerializer[$i].Invoke($propValue))
                   }
                   else
                   {
                       $hash[$propName] = $null
                   }
                }

                $results.Add($hash)
            }
        }

        # Write the results to the data table
        foreach( $obj in $results )
        {   
            # Add a row in data table
            $insertRow = $dt.NewRow()

            $device = New-Object Microsoft.ConfigurationManagement.AdminConsole.CMPivotParser.Device ([System.Environment]::MachineName), 1

            $insertRow.Device = [Microsoft.ConfigurationManagement.AdminConsole.CMPivotParser.Device]$device
        
            for( $i=0; $i -lt $propertyFilter.Length; $i++ )
            {
                $propName = $propertyFilter[$i]
                $propValue = $obj[$propName]

                if( $propValue -ne $null)
                {
                    switch($propertyTypes[$i])
                    {
                        "Boolean"
                        {
                            $insertRow[$propName] = [System.Boolean]$propValue
                            break
                        }
                        "Number"
                        {
                            $insertRow[$propName] = [System.Int64]$propValue
                            break
                        }
                        "TimeSpan"
                        {
                            $insertRow[$propName] = [System.TimeSpan]$propValue
                            break
                        }
                        "DateTime"
                        {
                            $insertRow[$propName] = ([System.DateTime]$propValue).ToUniversalTime()
                            break                
                        }
                        default
                        {
                            $insertRow[$propName] = $propValue
                        }
                    }
                }
                else
                {
                    $insertRow[$propName] = [System.DBNull]::Value
                }
            }
            $dt.Rows.Add($insertRow)
        }

        # Add the data table to list
        $datatables.Add($dt)
    }

    # Call the static method to evaluate the pivot query
    $maxResultSize = 128000
    $moreResults = $false
    $eval_result = [Microsoft.ConfigurationManagement.AdminConsole.CMPivotParser.KustoParser]::Evaluate($kustoquery, $datatables, $maxResultSize, [ref]$moreResults)

    # Add an attribute to result node to indicate if there should be more results
    $writer.WriteAttributeString("moreResults", $moreResults.ToString())

    # Write the results to Xml
    foreach ( $dr in $eval_result.Rows )
    {
        $writer.WriteStartElement("e")
        
        $writer.WriteAttributeString("_i", 0 )

        foreach ( $dc in $eval_result.Columns )
        {
            $prop = $dc.ColumnName

            # Skip Device column in writing to xml
            if ($prop -eq 'Device')
            {
                continue
            }
            $Value = $dr[$prop]
            
            if( !([DBNull]::Value).Equals($Value) )
            {
                if( $Value.GetType() -eq [DateTime] )
                {
                    $writer.WriteAttributeString("$prop", $Value.ToString("yyyy-MM-dd HH:mm:ss", [CultureInfo]::InvariantCulture))
                }
                else
                {
                    $writer.WriteAttributeString("$prop", $Value.ToString() )
                }
            }
        }

        $writer.WriteEndElement()
    }
}
Catch
{
    #format the exception as an xml 
    $sb = New-Object System.Text.StringBuilder
    $sw = New-Object System.IO.StringWriter($sb)
    $writer = New-Object System.Xml.XmlTextWriter($sw)

    $writer.WriteStartDocument()
    $writer.WriteStartElement("result")
    $writer.WriteAttributeString("ResultCode", 0x80004005 )
    $writer.WriteStartElement("error")
    $writer.WriteAttributeString("ErrorMessage", $_.Exception.Message )
    $writer.WriteEndElement()

    # Dispose the datatable if catch an exception
    if( $dt -ne $null )
    {
        $dt.Dispose()
		$datatables = $null
    }
}

# Finish off Xml
$writer.WriteEndElement()
$writer.WriteEndDocument()
$writer.Flush()
$writer.Close()

$writer.Close()
$sw.Dispose()

$Bytes = [System.Text.Encoding]::Unicode.GetBytes($sb.ToString())

if( $Bytes.Length -lt 4096 ) 
{
    return [Convert]::ToBase64String($Bytes)
}
else
{
    # Otherwise compress
    [System.IO.MemoryStream] $output = New-Object System.IO.MemoryStream
    $gzipStream = New-Object System.IO.Compression.GzipStream $output, ([IO.Compression.CompressionMode]::Compress)
    $gzipStream.Write( $Bytes, 0, $Bytes.Length )
    $gzipStream.Close()
    $output.Close()

    return [Convert]::ToBase64String($output.ToArray())
}

# SIG # Begin signature block
# MIIoLgYJKoZIhvcNAQcCoIIoHzCCKBsCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCAv1y7bbl/Z2ROR
# haYZQJi4F1rvnbVsXmOqFWBHtNCRXqCCDXYwggX0MIID3KADAgECAhMzAAADrzBA
# DkyjTQVBAAAAAAOvMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjMxMTE2MTkwOTAwWhcNMjQxMTE0MTkwOTAwWjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQDOS8s1ra6f0YGtg0OhEaQa/t3Q+q1MEHhWJhqQVuO5amYXQpy8MDPNoJYk+FWA
# hePP5LxwcSge5aen+f5Q6WNPd6EDxGzotvVpNi5ve0H97S3F7C/axDfKxyNh21MG
# 0W8Sb0vxi/vorcLHOL9i+t2D6yvvDzLlEefUCbQV/zGCBjXGlYJcUj6RAzXyeNAN
# xSpKXAGd7Fh+ocGHPPphcD9LQTOJgG7Y7aYztHqBLJiQQ4eAgZNU4ac6+8LnEGAL
# go1ydC5BJEuJQjYKbNTy959HrKSu7LO3Ws0w8jw6pYdC1IMpdTkk2puTgY2PDNzB
# tLM4evG7FYer3WX+8t1UMYNTAgMBAAGjggFzMIIBbzAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQURxxxNPIEPGSO8kqz+bgCAQWGXsEw
# RQYDVR0RBD4wPKQ6MDgxHjAcBgNVBAsTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEW
# MBQGA1UEBRMNMjMwMDEyKzUwMTgyNjAfBgNVHSMEGDAWgBRIbmTlUAXTgqoXNzci
# tW2oynUClTBUBgNVHR8ETTBLMEmgR6BFhkNodHRwOi8vd3d3Lm1pY3Jvc29mdC5j
# b20vcGtpb3BzL2NybC9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3JsMGEG
# CCsGAQUFBwEBBFUwUzBRBggrBgEFBQcwAoZFaHR0cDovL3d3dy5taWNyb3NvZnQu
# Y29tL3BraW9wcy9jZXJ0cy9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3J0
# MAwGA1UdEwEB/wQCMAAwDQYJKoZIhvcNAQELBQADggIBAISxFt/zR2frTFPB45Yd
# mhZpB2nNJoOoi+qlgcTlnO4QwlYN1w/vYwbDy/oFJolD5r6FMJd0RGcgEM8q9TgQ
# 2OC7gQEmhweVJ7yuKJlQBH7P7Pg5RiqgV3cSonJ+OM4kFHbP3gPLiyzssSQdRuPY
# 1mIWoGg9i7Y4ZC8ST7WhpSyc0pns2XsUe1XsIjaUcGu7zd7gg97eCUiLRdVklPmp
# XobH9CEAWakRUGNICYN2AgjhRTC4j3KJfqMkU04R6Toyh4/Toswm1uoDcGr5laYn
# TfcX3u5WnJqJLhuPe8Uj9kGAOcyo0O1mNwDa+LhFEzB6CB32+wfJMumfr6degvLT
# e8x55urQLeTjimBQgS49BSUkhFN7ois3cZyNpnrMca5AZaC7pLI72vuqSsSlLalG
# OcZmPHZGYJqZ0BacN274OZ80Q8B11iNokns9Od348bMb5Z4fihxaBWebl8kWEi2O
# PvQImOAeq3nt7UWJBzJYLAGEpfasaA3ZQgIcEXdD+uwo6ymMzDY6UamFOfYqYWXk
# ntxDGu7ngD2ugKUuccYKJJRiiz+LAUcj90BVcSHRLQop9N8zoALr/1sJuwPrVAtx
# HNEgSW+AKBqIxYWM4Ev32l6agSUAezLMbq5f3d8x9qzT031jMDT+sUAoCw0M5wVt
# CUQcqINPuYjbS1WgJyZIiEkBMIIHejCCBWKgAwIBAgIKYQ6Q0gAAAAAAAzANBgkq
# hkiG9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24x
# EDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlv
# bjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5
# IDIwMTEwHhcNMTEwNzA4MjA1OTA5WhcNMjYwNzA4MjEwOTA5WjB+MQswCQYDVQQG
# EwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwG
# A1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSgwJgYDVQQDEx9NaWNyb3NvZnQg
# Q29kZSBTaWduaW5nIFBDQSAyMDExMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIIC
# CgKCAgEAq/D6chAcLq3YbqqCEE00uvK2WCGfQhsqa+laUKq4BjgaBEm6f8MMHt03
# a8YS2AvwOMKZBrDIOdUBFDFC04kNeWSHfpRgJGyvnkmc6Whe0t+bU7IKLMOv2akr
# rnoJr9eWWcpgGgXpZnboMlImEi/nqwhQz7NEt13YxC4Ddato88tt8zpcoRb0Rrrg
# OGSsbmQ1eKagYw8t00CT+OPeBw3VXHmlSSnnDb6gE3e+lD3v++MrWhAfTVYoonpy
# 4BI6t0le2O3tQ5GD2Xuye4Yb2T6xjF3oiU+EGvKhL1nkkDstrjNYxbc+/jLTswM9
# sbKvkjh+0p2ALPVOVpEhNSXDOW5kf1O6nA+tGSOEy/S6A4aN91/w0FK/jJSHvMAh
# dCVfGCi2zCcoOCWYOUo2z3yxkq4cI6epZuxhH2rhKEmdX4jiJV3TIUs+UsS1Vz8k
# A/DRelsv1SPjcF0PUUZ3s/gA4bysAoJf28AVs70b1FVL5zmhD+kjSbwYuER8ReTB
# w3J64HLnJN+/RpnF78IcV9uDjexNSTCnq47f7Fufr/zdsGbiwZeBe+3W7UvnSSmn
# Eyimp31ngOaKYnhfsi+E11ecXL93KCjx7W3DKI8sj0A3T8HhhUSJxAlMxdSlQy90
# lfdu+HggWCwTXWCVmj5PM4TasIgX3p5O9JawvEagbJjS4NaIjAsCAwEAAaOCAe0w
# ggHpMBAGCSsGAQQBgjcVAQQDAgEAMB0GA1UdDgQWBBRIbmTlUAXTgqoXNzcitW2o
# ynUClTAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMCAYYwDwYD
# VR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBRyLToCMZBDuRQFTuHqp8cx0SOJNDBa
# BgNVHR8EUzBRME+gTaBLhklodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2Ny
# bC9wcm9kdWN0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3JsMF4GCCsG
# AQUFBwEBBFIwUDBOBggrBgEFBQcwAoZCaHR0cDovL3d3dy5taWNyb3NvZnQuY29t
# L3BraS9jZXJ0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3J0MIGfBgNV
# HSAEgZcwgZQwgZEGCSsGAQQBgjcuAzCBgzA/BggrBgEFBQcCARYzaHR0cDovL3d3
# dy5taWNyb3NvZnQuY29tL3BraW9wcy9kb2NzL3ByaW1hcnljcHMuaHRtMEAGCCsG
# AQUFBwICMDQeMiAdAEwAZQBnAGEAbABfAHAAbwBsAGkAYwB5AF8AcwB0AGEAdABl
# AG0AZQBuAHQALiAdMA0GCSqGSIb3DQEBCwUAA4ICAQBn8oalmOBUeRou09h0ZyKb
# C5YR4WOSmUKWfdJ5DJDBZV8uLD74w3LRbYP+vj/oCso7v0epo/Np22O/IjWll11l
# hJB9i0ZQVdgMknzSGksc8zxCi1LQsP1r4z4HLimb5j0bpdS1HXeUOeLpZMlEPXh6
# I/MTfaaQdION9MsmAkYqwooQu6SpBQyb7Wj6aC6VoCo/KmtYSWMfCWluWpiW5IP0
# wI/zRive/DvQvTXvbiWu5a8n7dDd8w6vmSiXmE0OPQvyCInWH8MyGOLwxS3OW560
# STkKxgrCxq2u5bLZ2xWIUUVYODJxJxp/sfQn+N4sOiBpmLJZiWhub6e3dMNABQam
# ASooPoI/E01mC8CzTfXhj38cbxV9Rad25UAqZaPDXVJihsMdYzaXht/a8/jyFqGa
# J+HNpZfQ7l1jQeNbB5yHPgZ3BtEGsXUfFL5hYbXw3MYbBL7fQccOKO7eZS/sl/ah
# XJbYANahRr1Z85elCUtIEJmAH9AAKcWxm6U/RXceNcbSoqKfenoi+kiVH6v7RyOA
# 9Z74v2u3S5fi63V4GuzqN5l5GEv/1rMjaHXmr/r8i+sLgOppO6/8MO0ETI7f33Vt
# Y5E90Z1WTk+/gFcioXgRMiF670EKsT/7qMykXcGhiJtXcVZOSEXAQsmbdlsKgEhr
# /Xmfwb1tbWrJUnMTDXpQzTGCGg4wghoKAgEBMIGVMH4xCzAJBgNVBAYTAlVTMRMw
# EQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVN
# aWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNp
# Z25pbmcgUENBIDIwMTECEzMAAAOvMEAOTKNNBUEAAAAAA68wDQYJYIZIAWUDBAIB
# BQCggbIwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYBBAGCNwIBCzEO
# MAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEICqnZwMfUt9rGIy2pHDrE/MG
# ZNDTTiscvWfUfhrEZQf6MEYGCisGAQQBgjcCAQwxODA2oBiAFgBDAE0AUABpAHYA
# bwB0AC4AcABzADGhGoAYaHR0cDovL3d3dy5taWNyb3NvZnQuY29tMA0GCSqGSIb3
# DQEBAQUABIIBADFaXWqaqCOirif0jHo/sNpLvVMurWHwNGao7yHgh0lQIIGMAZJc
# 1+rqXqxGnk3KbO08cqZZ5HLBURFChEi0G0MpkeBdzZaSPC9wtL06WkoyuoWLHWs5
# 3ah5+rNxoVORFhbN2yVvs3RKQkAUVTT/PrtZ67ImK5w0jvQoMiLW2hdDkt3qMgbi
# JipJ6o1VAxAYDG7/7xzk3tHHE+Pqu2Gxe/2dCubZJTBKXIHuTCFaqGPIRJAG82IN
# EuaxOvzwD63W0Dzi3qzqCmJ58pQSuJmRBVcVf2apsquhmXE8e2/huI3XItMGWrDC
# TmdXLAjEuxRi8eMGzI5HQwGzyqnugsKXs7+hgheUMIIXkAYKKwYBBAGCNwMDATGC
# F4Awghd8BgkqhkiG9w0BBwKgghdtMIIXaQIBAzEPMA0GCWCGSAFlAwQCAQUAMIIB
# UgYLKoZIhvcNAQkQAQSgggFBBIIBPTCCATkCAQEGCisGAQQBhFkKAwEwMTANBglg
# hkgBZQMEAgEFAAQggmCrYHtlxXkb7JuwKKuHFcEtuUpvX3T8FyO9jiO36RkCBmYy
# vp6UBxgTMjAyNDA1MDIyMDU1MzguODY2WjAEgAIB9KCB0aSBzjCByzELMAkGA1UE
# BhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAc
# BgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjElMCMGA1UECxMcTWljcm9zb2Z0
# IEFtZXJpY2EgT3BlcmF0aW9uczEnMCUGA1UECxMeblNoaWVsZCBUU1MgRVNOOjky
# MDAtMDVFMC1EOTQ3MSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2
# aWNloIIR6jCCByAwggUIoAMCAQICEzMAAAHnLo8vkwtPG+kAAQAAAecwDQYJKoZI
# hvcNAQELBQAwfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAO
# BgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEm
# MCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwHhcNMjMxMjA2
# MTg0NTE5WhcNMjUwMzA1MTg0NTE5WjCByzELMAkGA1UEBhMCVVMxEzARBgNVBAgT
# Cldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29m
# dCBDb3Jwb3JhdGlvbjElMCMGA1UECxMcTWljcm9zb2Z0IEFtZXJpY2EgT3BlcmF0
# aW9uczEnMCUGA1UECxMeblNoaWVsZCBUU1MgRVNOOjkyMDAtMDVFMC1EOTQ3MSUw
# IwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNlMIICIjANBgkqhkiG
# 9w0BAQEFAAOCAg8AMIICCgKCAgEAwlefL+CLkOufVzzNQ7WljL/fx0VAuZHYhBfP
# WAT+v0Z+5I6jJGeREnpn+RJYuAi7UFUnn0aRdY+0uSyyorDFjhkWi3GlWxk33JiN
# bzESdbczMAjSKAqv78vFh/EHVdQfwG+bCvkPciL8xsOO031zxPEZa2rsCv3vp1p8
# DLdOtGpBGYiSc9VYdS4UmCmoj/WdtxGZhhEwlooJCm3LgJ4b4d8qzGvPbgX2nh0G
# RBxkKnbJDOPBAXFklnaYkkgYgMcoR1JG5J5fTz87Qf0lMc0WY1M1h4PW39ZqmdHC
# IgFgtBIyuzjYZUHykkR1SyizT6Zd//lC+F43NGL3anPPIDi1K//OE/f8Sua/Nrpb
# 0adgPP2q/XBuFu+udLimgMUQJoC+ISoCF+f9GiALG8qiTmujiBkhfWvg315dS6UD
# zSke/drHBe7Yw+VqsCLon0vWFIhzL0S44ypNEkglf5qVwtAaD5JOWrH8a6yWwrCX
# jx0jhG5aSc0Zs2j+jjF8EXK2+01xUDrE5CrqpFr72CD71cwuvFDPjLJCz5XdXqnT
# jjCu0m239rRkmX9/ojsFkDHFlwfYMOYCtwCGCtPFpCSbssz6n4rYLm3UQpmK/Qlb
# DTrlvsBw2BoXIiQxdi5K45BVI1HF0iCXfX9rLGIrWfQrqxle+AUHH68Y75NS/I77
# Te5rpSMCAwEAAaOCAUkwggFFMB0GA1UdDgQWBBTP/uCYgJ82OHaRH/2Za4dSu96P
# WDAfBgNVHSMEGDAWgBSfpxVdAF5iXYP05dJlpxtTNRnpcjBfBgNVHR8EWDBWMFSg
# UqBQhk5odHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NybC9NaWNyb3Nv
# ZnQlMjBUaW1lLVN0YW1wJTIwUENBJTIwMjAxMCgxKS5jcmwwbAYIKwYBBQUHAQEE
# YDBeMFwGCCsGAQUFBzAChlBodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3Bz
# L2NlcnRzL01pY3Jvc29mdCUyMFRpbWUtU3RhbXAlMjBQQ0ElMjAyMDEwKDEpLmNy
# dDAMBgNVHRMBAf8EAjAAMBYGA1UdJQEB/wQMMAoGCCsGAQUFBwMIMA4GA1UdDwEB
# /wQEAwIHgDANBgkqhkiG9w0BAQsFAAOCAgEAdKHw25PpZVotXAup7H4nuSbadPaO
# m+gEQqb7Qz6tihT/oYvlDTT+yxnIirnJKlwpgUxSIXwXhksb5OsnKJHUK9/NeaRD
# mmFk5x70NPvISsvOq9ReK3wbuKBweXE8tPE+KIaxvzmBvwf4DZ89Dper+7v6hI8+
# PM12emZcShsmcCpimVmgXdg2BMMyqXS5AcbOgOnp1mUdI2PquRXW1eOYIRkyoEq+
# RAgDpyw+J4ycH4yKtJkWVsA2UKF7SUmlR0rtpR0C92BxBYpLp21EyXzXwQyy+xr/
# rE5kYg2ZMuTgMaCxtoGk37ohW36Zknz3IJeQjlM3zEJ86Sn1+vhZCNEEDb7j6VrA
# 1PLEfrp4tlZg6O65qia6JuIoYFTXS2jHzVKrwS+WYkitc5mhCwSfWvmDoxOaZkmq
# 1ubBm5+4lZBdlvSUCDh+rRlixSUuR7N+s2oZKB4fIg/ety3ho2apBbrCmlFu9sjI
# /8sU3hhAzqCK9+ZMF8a9VLvs5Lq9svhbjWNKGY6ac6feQFtZXoT9MWjvqAVdV372
# grq/weT1QKdsc66LDBFHAMKSaYqPlWHyLnxo+5nl3BkGFgPFJq/CugLqPiZY/CHh
# UupUryoakKZnQcwDBqjzkCrdTsN2V8XoSu7wIopt2YgC5TNCueOpNLGa8XWT4KZs
# +zvMPYBy7smQEHswggdxMIIFWaADAgECAhMzAAAAFcXna54Cm0mZAAAAAAAVMA0G
# CSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3Rv
# bjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0
# aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0ZSBBdXRob3Jp
# dHkgMjAxMDAeFw0yMTA5MzAxODIyMjVaFw0zMDA5MzAxODMyMjVaMHwxCzAJBgNV
# BAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4w
# HAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29m
# dCBUaW1lLVN0YW1wIFBDQSAyMDEwMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIIC
# CgKCAgEA5OGmTOe0ciELeaLL1yR5vQ7VgtP97pwHB9KpbE51yMo1V/YBf2xK4OK9
# uT4XYDP/XE/HZveVU3Fa4n5KWv64NmeFRiMMtY0Tz3cywBAY6GB9alKDRLemjkZr
# BxTzxXb1hlDcwUTIcVxRMTegCjhuje3XD9gmU3w5YQJ6xKr9cmmvHaus9ja+NSZk
# 2pg7uhp7M62AW36MEBydUv626GIl3GoPz130/o5Tz9bshVZN7928jaTjkY+yOSxR
# nOlwaQ3KNi1wjjHINSi947SHJMPgyY9+tVSP3PoFVZhtaDuaRr3tpK56KTesy+uD
# RedGbsoy1cCGMFxPLOJiss254o2I5JasAUq7vnGpF1tnYN74kpEeHT39IM9zfUGa
# RnXNxF803RKJ1v2lIH1+/NmeRd+2ci/bfV+AutuqfjbsNkz2K26oElHovwUDo9Fz
# pk03dJQcNIIP8BDyt0cY7afomXw/TNuvXsLz1dhzPUNOwTM5TI4CvEJoLhDqhFFG
# 4tG9ahhaYQFzymeiXtcodgLiMxhy16cg8ML6EgrXY28MyTZki1ugpoMhXV8wdJGU
# lNi5UPkLiWHzNgY1GIRH29wb0f2y1BzFa/ZcUlFdEtsluq9QBXpsxREdcu+N+VLE
# hReTwDwV2xo3xwgVGD94q0W29R6HXtqPnhZyacaue7e3PmriLq0CAwEAAaOCAd0w
# ggHZMBIGCSsGAQQBgjcVAQQFAgMBAAEwIwYJKwYBBAGCNxUCBBYEFCqnUv5kxJq+
# gpE8RjUpzxD/LwTuMB0GA1UdDgQWBBSfpxVdAF5iXYP05dJlpxtTNRnpcjBcBgNV
# HSAEVTBTMFEGDCsGAQQBgjdMg30BATBBMD8GCCsGAQUFBwIBFjNodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vcGtpb3BzL0RvY3MvUmVwb3NpdG9yeS5odG0wEwYDVR0l
# BAwwCgYIKwYBBQUHAwgwGQYJKwYBBAGCNxQCBAweCgBTAHUAYgBDAEEwCwYDVR0P
# BAQDAgGGMA8GA1UdEwEB/wQFMAMBAf8wHwYDVR0jBBgwFoAU1fZWy4/oolxiaNE9
# lJBb186aGMQwVgYDVR0fBE8wTTBLoEmgR4ZFaHR0cDovL2NybC5taWNyb3NvZnQu
# Y29tL3BraS9jcmwvcHJvZHVjdHMvTWljUm9vQ2VyQXV0XzIwMTAtMDYtMjMuY3Js
# MFoGCCsGAQUFBwEBBE4wTDBKBggrBgEFBQcwAoY+aHR0cDovL3d3dy5taWNyb3Nv
# ZnQuY29tL3BraS9jZXJ0cy9NaWNSb29DZXJBdXRfMjAxMC0wNi0yMy5jcnQwDQYJ
# KoZIhvcNAQELBQADggIBAJ1VffwqreEsH2cBMSRb4Z5yS/ypb+pcFLY+TkdkeLEG
# k5c9MTO1OdfCcTY/2mRsfNB1OW27DzHkwo/7bNGhlBgi7ulmZzpTTd2YurYeeNg2
# LpypglYAA7AFvonoaeC6Ce5732pvvinLbtg/SHUB2RjebYIM9W0jVOR4U3UkV7nd
# n/OOPcbzaN9l9qRWqveVtihVJ9AkvUCgvxm2EhIRXT0n4ECWOKz3+SmJw7wXsFSF
# QrP8DJ6LGYnn8AtqgcKBGUIZUnWKNsIdw2FzLixre24/LAl4FOmRsqlb30mjdAy8
# 7JGA0j3mSj5mO0+7hvoyGtmW9I/2kQH2zsZ0/fZMcm8Qq3UwxTSwethQ/gpY3UA8
# x1RtnWN0SCyxTkctwRQEcb9k+SS+c23Kjgm9swFXSVRk2XPXfx5bRAGOWhmRaw2f
# pCjcZxkoJLo4S5pu+yFUa2pFEUep8beuyOiJXk+d0tBMdrVXVAmxaQFEfnyhYWxz
# /gq77EFmPWn9y8FBSX5+k77L+DvktxW/tM4+pTFRhLy/AsGConsXHRWJjXD+57XQ
# KBqJC4822rpM+Zv/Cuk0+CQ1ZyvgDbjmjJnW4SLq8CdCPSWU5nR0W2rRnj7tfqAx
# M328y+l7vzhwRNGQ8cirOoo6CGJ/2XBjU02N7oJtpQUQwXEGahC0HVUzWLOhcGby
# oYIDTTCCAjUCAQEwgfmhgdGkgc4wgcsxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpX
# YXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQg
# Q29ycG9yYXRpb24xJTAjBgNVBAsTHE1pY3Jvc29mdCBBbWVyaWNhIE9wZXJhdGlv
# bnMxJzAlBgNVBAsTHm5TaGllbGQgVFNTIEVTTjo5MjAwLTA1RTAtRDk0NzElMCMG
# A1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgU2VydmljZaIjCgEBMAcGBSsOAwIa
# AxUAs3IE5xmrEsHv3a7vnD3tTRf78EOggYMwgYCkfjB8MQswCQYDVQQGEwJVUzET
# MBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMV
# TWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1T
# dGFtcCBQQ0EgMjAxMDANBgkqhkiG9w0BAQsFAAIFAOnd5dYwIhgPMjAyNDA1MDIx
# MDEzNDJaGA8yMDI0MDUwMzEwMTM0MlowdDA6BgorBgEEAYRZCgQBMSwwKjAKAgUA
# 6d3l1gIBADAHAgEAAgIkwDAHAgEAAgISzTAKAgUA6d83VgIBADA2BgorBgEEAYRZ
# CgQCMSgwJjAMBgorBgEEAYRZCgMCoAowCAIBAAIDB6EgoQowCAIBAAIDAYagMA0G
# CSqGSIb3DQEBCwUAA4IBAQAjzwayYiHqOIRakro6W/YMRcD8FQxaWF7WLOHdYJiK
# tuKOpyX9uyagacOo0hvAMyaxNyz0vKPnkali6fGfcJLISU380znZcPw94695O732
# gtFVoNuBCotWs8RnvP4PMm0+DY2UVd3r2lVzTkZHyWVTxNNDoq0Eu+lkxonwxSrG
# B7aMuDpynRdA4Zr3YCZnF6yKxNJKf+Njan1MT4IagyS5sGmMIEhXAt0GIkQ7wsuW
# 8l2cvOwxIG5JxzFYSqeGTgCgCpmdvsymaNrZrp5Eh4Qskh2gq+cjjVPPBqvaZMIG
# bxEGw7m6r06/+4aKf0J+J/IiiFrSc4wBjTbK5osiFtl4MYIEDTCCBAkCAQEwgZMw
# fDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1Jl
# ZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMd
# TWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTACEzMAAAHnLo8vkwtPG+kAAQAA
# AecwDQYJYIZIAWUDBAIBBQCgggFKMBoGCSqGSIb3DQEJAzENBgsqhkiG9w0BCRAB
# BDAvBgkqhkiG9w0BCQQxIgQgUfgL0VPeaCueJjnRMysA6NbDmRvDW2PBFdK60L/k
# oQ4wgfoGCyqGSIb3DQEJEAIvMYHqMIHnMIHkMIG9BCDlNl0NdmqG/Q3gxVzPVBR3
# hF++Bb9AAb0DBu6gudZzrTCBmDCBgKR+MHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQI
# EwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3Nv
# ZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBD
# QSAyMDEwAhMzAAAB5y6PL5MLTxvpAAEAAAHnMCIEILppQANWlLK6RPMd0YbeVSS/
# gACxPQyaYSJMzpSR+8v+MA0GCSqGSIb3DQEBCwUABIICAJvGTMcABx5KCQpqONyc
# 8Gs9MofftlbkUW0Z8k97uYy1xjwuHucVDW3zaKhvKDZrz/URb9dAx4IqkuQAtNVZ
# JpqXpoQ55iiXB34WIIPopZbyu5cAagveYzJi4AuHwg1ucTun16OgZEjEOK2LKcsQ
# iJuXcnExxpbdBA42iijdbYdnFgLqGqGYXhKkULPaz/W0aAJu1bMdRIDr6ORgby8k
# kT9vKWQX2D+5kuEdEzOeXBi94QLfNHRIDcTjDBXh12gJx+f8EZrYzPXrbRgdTRMd
# aRrKKaQ5nZ+FqXmts8fU9G8UHz8LPNLFtL3E29AcHBFm08CjNnj6AWhgYDwq1b/t
# 187Esmvmi1YKjqy+TWI3orp/yMVejMWSmY1x0R3Ejp9eiNjq+1uPCPDJD6eEajI9
# 2Wy19SlUwhknzwsltHmKr5vM8O1P23Xq/5fdF9kAtb/MR9D+jfMdk+WQxk6A05+X
# MkeXFFzqDEOKaLduQZaOgv2KwphqJjOnYxNuxdwgFZL6qx6SJwgcZjetOHXZdUPc
# 6zl+4qEb84Y4sav1wCyzp9olf87huXQSdXn7TpYE5b1WfPsDYu4sVref0KZBLuje
# TB8dBM3bUjVtc6XiAjVmAmlIkdqSa3xUPcirsMDAozKzXlXLswbT5sZiRs8fkvmE
# 5Z4Tka5pDpwccBxJebFELynb
# SIG # End signature block
 
 